package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;

import java.sql.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recMakanan;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<Makanan> listMakanan;
    void initData(){
        this.listMakanan = new ArrayList<>();
        listMakanan.add(new Makanan("Bakso",
                "Makanan yang terbuat dari campuran daging sapi giling dan tepung tapioka.",
                "20000", R.drawable.bakso));
        listMakanan.add(new Makanan("Pempek",
                "Makanan berbahan daging ikan dan tepung kanji.",
                "15000", R.drawable.pempek));
        listMakanan.add(new Makanan("Rendang",
                "Terbuat dari olahan daging yang dimasak dengan bumbu rempah.",
                "23000", R.drawable.rendang));
        listMakanan.add(new Makanan("Sate",
                "Daging ayam, sapi, kambing, dan kerbau.",
                "25000", R.drawable.sate));
        listMakanan.add(new Makanan("Soto",
                "Daging ayam dan daging sapi.",
                "11000", R.drawable.soto));
        listMakanan.add(new Makanan("Rawon",
                "Disajikan dengan potongan daging sapi, rebusan kecambah, dam telur asin serta kerupuk udang.",
                "17000", R.drawable.rawon));
        listMakanan.add(new Makanan("Gado-Gado",
                "Isian kangkung, wortel, labu siam, selada, timun dan irisan tempe yang disiram dengan saus kacang.",
                "10000", R.drawable.gado));
    }
    void data(){
        recMakanan = findViewById(R.id.rec_makanan);
        adapter = new MakananAdapter(this,listMakanan);
        layoutManager = new LinearLayoutManager(this);
        recMakanan.setLayoutManager(layoutManager);
        recMakanan.setAdapter(adapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        data();
    }
}

