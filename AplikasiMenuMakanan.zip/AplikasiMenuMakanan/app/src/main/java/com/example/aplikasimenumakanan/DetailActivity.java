package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    ImageView imgMakanan;
    TextView txtMakanan, txtDeskripsi, txtTotal;
    String nama, harga, deskripsi;
    Integer gambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Detail Makanan");
        nama = getIntent().getStringExtra("Nama Makanan");
        harga = getIntent().getStringExtra("Harga Makanan");
        deskripsi = getIntent().getStringExtra("Deskripsi Makanan");
        setTitle("Detail Makanan: "+nama);
        imgMakanan = findViewById(R.id.imgMakanan);
        imgMakanan.setImageResource(getIntent().getIntExtra("Image", 0));
        txtMakanan = findViewById(R.id.txtMakanan);
        txtMakanan.setText(nama);
        txtDeskripsi = findViewById(R.id.txtDeskripsi);
        txtDeskripsi.setText(deskripsi);
        txtTotal = findViewById(R.id.txtTotal);
        txtTotal.setText(harga);
    }
}